Find the small yellow box and touch it to "win" the game! Move the character with WASD or
arrow keys and jump with space bar.

Did by myself
1. Rock shaders
2. Bush animations
3. Bush berries
4. Character model/shading
5. Character rigging/weight painting
6. Character movement
7. UI and Win States
8. Terrain model and shader
9. Tree model and shader
10. Clouds and shader
11. Bird, shader, and animation


Third Party Resources/Tutorials
1. Rock Shape Tutorial = https://www.youtube.com/watch?v=4EqLyGsu3AA&ab_channel=CGGeek
2. Bushes Shape = https://www.youtube.com/watch?v=K7o3gt9D26g

Side Note:
I could not import textures for the terrain and rocks that I spent a good amount of time on. If possible, please look
at them in their blender files. The terrain file has an overworld material with a new water shader to use (the object that uses
the material is turned off currently), and the rocks
file has multiple types of rocks using different shaders. I am sorry I could not add them but it was because I have barely any
practice with baking my own textures, I hope you will still enjoy the models nevertheless!
